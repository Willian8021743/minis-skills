#!/usr/bin/env python3
"""office-hub helper: dump Office files as text, or scaffold new ones.

  python3 office.py read FILE [--sheet NAME] [--limit N] [--json]
  python3 office.py new  FILE --kind docx|xlsx|pptx [--title T] [--sheets A,B]
"""
import argparse
import json
import os
import sys
import zipfile


def read_xlsx(path, sheet=None, limit=200, formulas=False):
    from openpyxl import load_workbook

    wb = load_workbook(path, data_only=not formulas, read_only=True)
    lines = []
    for ws in wb.worksheets:
        if sheet and ws.title != sheet:
            continue
        lines.append(f"## sheet: {ws.title}  ({ws.max_row} rows x {ws.max_column} cols)")
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i >= limit:
                lines.append(f"... truncated at {limit} rows")
                break
            cells = ["None" if c is None else str(c).replace("\n", " ").strip() for c in row]
            if any(c and c != "None" for c in cells):
                lines.append(" | ".join(cells).rstrip(" |"))
    wb.close()
    return "\n".join(lines)


def read_docx(path, limit=100000):
    import docx

    d = docx.Document(path)
    out = []
    for p in d.paragraphs:
        t = p.text.strip()
        if not t:
            continue
        style = p.style.name if p.style is not None else ""
        prefix = f"[{style}] " if style and style.lower().startswith(("heading", "title")) else ""
        out.append(prefix + t)
    for ti, table in enumerate(d.tables, 1):
        out.append(f"\n## table {ti} ({len(table.rows)}x{len(table.columns)})")
        for row in table.rows:
            out.append(" | ".join(c.text.strip().replace("\n", " ") for c in row.cells))
    return "\n".join(out)


def read_pptx(path):
    from pptx import Presentation

    prs = Presentation(path)
    out = [f"{len(prs.slides)} slides, {prs.slide_width}x{prs.slide_height} EMU"]
    for i, slide in enumerate(prs.slides, 1):
        title = ""
        try:
            if slide.shapes.title is not None:
                title = slide.shapes.title.text.strip()
        except Exception:
            pass
        out.append(f"\n## slide {i}: {title}")
        for shape in slide.shapes:
            if shape.has_text_frame:
                for p in shape.text_frame.paragraphs:
                    t = "".join(r.text for r in p.runs).strip()
                    if t:
                        out.append("  " + ("- " if p.level else "") + t)
            if getattr(shape, "has_table", False) and shape.has_table:
                for row in shape.table.rows:
                    out.append("  " + " | ".join(c.text.strip() for c in row.cells))
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip():
            out.append("  [notes] " + slide.notes_slide.notes_text_frame.text.strip())
    return "\n".join(out)


def read_vsdx(path):
    try:
        import vsdx

        with vsdx.VisioFile(path) as vf:
            out = [f"pages: {len(vf.pages)}"]
            for page in vf.pages:
                out.append(f"\n## page: {page.name}")
                for shape in page.child_shapes:
                    txt = getattr(shape, "text", "") or ""
                    if txt.strip():
                        out.append(f"- {shape.shape_id}: {txt.strip()}")
            return "\n".join(out)
    except Exception as exc:  # fall back to raw OOXML text scan
        out = [f"vsdx lib failed ({exc}); raw XML text scan:"]
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                if n.startswith("visio/pages/page") and n.endswith(".xml"):
                    raw = z.read(n).decode("utf-8", "ignore")
                    import re

                    texts = re.findall(r"<Text[^>]*>(.*?)</Text>", raw, re.S)
                    if texts:
                        out.append(f"\n## {n}")
                        for t in texts:
                            clean = re.sub(r"<[^>]+>", "", t).strip()
                            if clean:
                                out.append("- " + clean)
        return "\n".join(out)


def new_docx(path, title):
    import docx

    d = docx.Document()
    if title:
        d.add_heading(title, level=0)
    d.add_paragraph("")
    d.save(path)


def new_xlsx(path, sheets):
    from openpyxl import Workbook

    wb = Workbook()
    names = sheets or ["Sheet1"]
    wb.active.title = names[0]
    for n in names[1:]:
        wb.create_sheet(n)
    wb.save(path)


def new_pptx(path, title):
    from pptx import Presentation
    from pptx.util import Inches

    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)  # 16:9
    s = prs.slides.add_slide(prs.slide_layouts[0])
    s.shapes.title.text = title or "Untitled"
    prs.save(path)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("read")
    r.add_argument("file")
    r.add_argument("--sheet")
    r.add_argument("--limit", type=int, default=200)
    r.add_argument("--formulas", action="store_true")
    n = sub.add_parser("new")
    n.add_argument("file")
    n.add_argument("--kind", required=True, choices=["docx", "xlsx", "pptx"])
    n.add_argument("--title", default="")
    n.add_argument("--sheets", default="")
    a = ap.parse_args()

    if a.cmd == "read":
        ext = os.path.splitext(a.file)[1].lower()
        if ext in (".xlsx", ".xlsm"):
            print(read_xlsx(a.file, a.sheet, a.limit, a.formulas))
        elif ext == ".docx":
            print(read_docx(a.file))
        elif ext == ".pptx":
            print(read_pptx(a.file))
        elif ext in (".vsdx", ".vsd"):
            print(read_vsdx(a.file))
        else:
            sys.exit(f"unsupported: {ext}")
        return

    sheets = [s for s in a.sheets.split(",") if s]
    if a.kind == "docx":
        new_docx(a.file, a.title)
    elif a.kind == "xlsx":
        new_xlsx(a.file, sheets)
    else:
        new_pptx(a.file, a.title)
    print(f"created {a.file}")


if __name__ == "__main__":
    main()
