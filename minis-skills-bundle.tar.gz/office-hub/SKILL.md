---
name: office-hub
version: 1.0.0
description: >
  Read, create and modify Microsoft Office files on-device: Word (.docx), Excel (.xlsx),
  PowerPoint (.pptx), plus read-only parsing of Visio (.vsdx). Use this skill whenever the user
  mentions Word, Excel, PowerPoint, PPT, Office, docx, xlsx, pptx, vsdx, Visio, 表格, 做表,
  写报告, 做PPT, 幻灯片, 简历, 财务报表, or asks to read, summarize, generate, edit, merge,
  split, or fill in any of these files. Works without LibreOffice or pandoc.
compatibility: >
  Python 3 with openpyxl (apk add py3-openpyxl), python-docx, python-pptx, vsdx (pip).
  No LibreOffice, no pandoc, no network needed.
---

# Office 三件套 + Visio

在本机读写 Office 文件，全部靠 Python 库，不依赖 LibreOffice。

## 环境

已装：`openpyxl 3.1` `python-docx 1.2` `python-pptx 1.0` `vsdx 0.6`。
缺了就用 `apk add py3-openpyxl`（Excel）或 `pip install python-docx python-pptx vsdx`。
路径一律用绝对路径，产物写到 `/var/minis/workspace/` 下再给用户链接。

## 助手脚本

```bash
P=/var/minis/skills/office-hub/scripts/office.py
python3 $P read 报表.xlsx [--sheet 汇总] [--limit 200] [--formulas]   # 输出竖线分隔的文本
python3 $P read 文档.docx      # 段落（带 Heading 标记）+ 表格
python3 $P read 幻灯片.pptx    # 每页标题、正文、表格、备注
python3 $P read 流程图.vsdx    # 页面和形状文字；失败自动回退到原始 XML 扫描
python3 $P new 新文件.xlsx --kind xlsx --sheets 汇总,明细
python3 $P new 新文档.docx --kind docx --title 标题
python3 $P new 新演示.pptx --kind pptx --title 封面标题
```

读取优先用脚本；要改结构、加样式时写 Python 脚本。

## Excel（openpyxl）

```python
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, Reference

wb = load_workbook("in.xlsx", data_only=True)   # data_only=True 读计算结果
ws = wb.active

# 写表头 + 样式
ws["A1"] = "月份"; ws["A1"].font = Font(bold=True, color="FFFFFF")
ws["A1"].fill = PatternFill("solid", fgColor="2F5597")
for c in ws[1]:
    c.alignment = Alignment(horizontal="center", vertical="center")
ws.freeze_panes = "A2"                          # 冻结首行
for i, w in enumerate([14, 12, 18], 1):
    ws.column_dimensions[get_column_letter(i)].width = w

# 公式、数字格式、边框
ws["C2"] = "=B2*1.1"; ws["C2"].number_format = "0.00%"
thin = Side(style="thin", color="BFBFBF")
for row in ws["A1:C10"]:
    for c in row:
        c.border = Border(left=thin, right=thin, top=thin, bottom=thin)

# 图表
chart = BarChart(); chart.title = "销售额"
chart.add_data(Reference(ws, min_col=2, min_row=1, max_row=ws.max_row), titles_from_data=True)
chart.set_categories(Reference(ws, min_col=1, min_row=2, max_row=ws.max_row))
ws.add_chart(chart, "E2")
wb.save("out.xlsx")
```

- `read_only=True` 处理大文件，`ws.iter_rows(values_only=True)` 逐行取。
- 合并单元格用 `ws.merge_cells("A1:D1")`；条件格式用 `openpyxl.formatting.rule`。
- 公式不会被计算：新写入的公式单元格没有缓存值，`data_only=True` 读到 `None`。
  要给用户看结果，就在本地用 Python 算好再写入数值，或用 `--formulas` 只展示公式原文。
- 旧格式 `.xls` 读不了，先让用户另存为 `.xlsx`；带宏的 `.xlsm` 用 `keep_vba=True`。

## Word（python-docx）

```python
import docx
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

doc = docx.Document()
doc.add_heading("报告标题", level=0)
p = doc.add_paragraph("正文段落，")
r = p.add_run("加粗强调"); r.bold = True
p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

# 中文字体必须同时设 eastAsia，否则中文回落到宋体
st = doc.styles["Normal"]
st.font.name = "PingFang SC"; st.font.size = Pt(11)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "PingFang SC")

t = doc.add_table(rows=1, cols=3); t.style = "Table Grid"
for i, h in enumerate(["项目", "数量", "金额"]):
    t.rows[0].cells[i].text = h
doc.add_picture("chart.png", width=Cm(14))
doc.add_page_break()
doc.save("out.docx")
```

- 读：`doc.paragraphs`（`p.style.name` 判断 Heading）、`doc.tables`、`section.header/footer`。
- 页眉页脚：`doc.sections[0].header.paragraphs[0].text = "..."`。
- 目录、页码域 python-docx 不直接支持，需要改 `w:fldSimple` XML；能不加就不加。
- `.doc` 老格式读不了，先转 `.docx`。

## PowerPoint（python-pptx）

```python
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor

prs = Presentation()
prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)   # 16:9
blank = prs.slide_layouts[6]

s = prs.slides.add_slide(blank)
tb = s.shapes.add_textbox(Inches(0.8), Inches(0.6), Inches(11), Inches(1.2))
tf = tb.text_frame; tf.text = "页面标题"
tf.paragraphs[0].font.size = Pt(36); tf.paragraphs[0].font.bold = True
tf.paragraphs[0].font.color.rgb = RGBColor(0x1F, 0x3A, 0x5F)

body = s.shapes.add_textbox(Inches(0.8), Inches(2), Inches(11), Inches(4)).text_frame
body.word_wrap = True
for line in ["要点一", "要点二"]:
    p = body.add_paragraph(); p.text = line; p.level = 0
    p.font.size = Pt(20)

s.shapes.add_picture("chart.png", Inches(8), Inches(2), width=Inches(4))

# 表格
tbl = s.shapes.add_table(3, 2, Inches(0.8), Inches(4), Inches(6), Inches(1.5)).table
tbl.cell(0, 0).text = "指标"
prs.save("out.pptx")
```

- 版面布局：`prs.slide_layouts` 里 0 是标题页、1 是标题+内容、5 是仅标题、6 是空白。
- 母版配色：`prs.slide_masters[0].theme` 不直接改，统一在每个 shape 上设字体和颜色。
- 备注：`slide.notes_slide.notes_text_frame.text = "..."`。
- 复用模板：`Presentation("模板.pptx")`，再按 layout 加页，能保留公司样式。

## Visio（.vsdx）

- 读：`vsdx` 库遍历 `pages` 和 `child_shapes`，取 `shape.text`、`shape.shape_id`；连线用 `page.connects`。
- `.vsdx` 本质是 zip + OOXML，库读失败就 `zipfile` 解 `visio/pages/page*.xml`，正则抽 `<Text>` 内容。
- 写：`vsdx` 能改文字并另存，但创建新图形不可靠。用户要"画流程图"时，改产 HTML/SVG 图（Mermaid 或手写 SVG），比生成 .vsdx 实用。
- 老格式 `.vsd`（二进制）完全读不了，需要用户在桌面端另存为 `.vsdx`。

## 格式转换的边界

| 想要 | 能不能 | 做法 |
|---|---|---|
| xlsx → csv / Markdown 表格 | 能 | openpyxl 读出来拼文本 |
| xlsx / docx / pptx → PDF | 不能直接转 | 无 LibreOffice；用 `pdf-converter` 从 Markdown 或 HTML 重建 PDF |
| docx → 纯文本 | 能 | python-docx 取段落 |
| pptx → 图片 | 不能 | 需要渲染器，改为在 HTML 里复刻版式 |
| docx ↔ pptx 互转 | 不建议 | 结构差异大，重排比转换可靠 |
| 批量合并多个 xlsx | 能 | 循环 `load_workbook`，`ws.append()` 汇总到一个工作簿 |

## 交付

生成文件后给用户 Markdown 链接，例如 `[报表.xlsx](minis://workspace/报表.xlsx)`。
文件名有中文时用工具返回的 `minis_url`，不要自己拼。
