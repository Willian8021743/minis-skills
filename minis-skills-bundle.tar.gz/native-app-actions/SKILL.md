---
name: native-app-actions
description: 用 iOS URL scheme 直接拉起本机原生 App 并带上参数（打开小红书搜四六级、打开微信、打开抖音等），而不是在内置浏览器里打开网页。用户说「打开某 App 查/搜/看某内容」「用本机 App 操作」「别在 Minis 里开网页」时使用。
---

# 本机 App 操作（URL Scheme 深链）

## 能力边界（必须先说清楚）

iOS 沙箱下，第三方 App **不能**：

- 模拟点击、滑动另一个 App 的界面
- 读取另一个 App 的屏幕内容
- 在另一个 App 内部自动输入（聊天框、搜索框）

第三方 App **能**：

- 用 URL scheme 拉起目标 App
- 把参数（搜索词、商品 id、页面路径）一并传过去，由目标 App 自己渲染
- 使用系统接口：提醒、日历、通知、剪贴板、HomeKit、健康数据等

所以「打开小红书查四六级」的正确实现是：拉起小红书并跳到该关键词的搜索结果页，而不是替用户点搜索框。

## 执行顺序

1. 先判断目标 App 是否可用：`apple-open "<scheme>"`，看返回的 `data.opened`。
2. `opened: true` → 已拉起，任务完成，向用户说明「已打开 X，搜索词已带上」。
3. `opened: false` → 两种可能：没装，或 scheme 变了。**不要静默退回浏览器**，先告诉用户「这台机器上拉不起 X」，再问是否改用网页版。
4. 只有用户同意后，才用 `minis-browser-use` 或 `apple-open https://...` 打开网页。

## 常见 App 的 scheme

| App | Scheme | 带参数示例 |
|---|---|---|
| 微信 | `weixin://` | — |
| 抖音 | `snssdk1128://` | `snssdk1128://search?keyword=<kw>`（版本差异大，失败就只拉起） |
| 小红书 | `xhsdiscover://` | `xhsdiscover://search/result?keyword=<urlencoded>` |
| 淘宝 | `taobao://` | `taobao://s.taobao.com/search?q=<kw>` |
| 支付宝 | `alipays://` | — |
| 哔哩哔哩 | `bilibili://` | `bilibili://search?keyword=<kw>` |
| 知乎 | `zhihu://` | — |
| 高德地图 | `iosamap://` | `iosamap://poi?sourceApplication=Minis&keywords=<kw>` |
| 系统地图 | `maps://` | `maps://?q=<kw>` |

关键词必须 URL 编码（`python3 -c "import urllib.parse;print(urllib.parse.quote('四六级'))"`）。

## 实测记录（2026-10-20，iPhone 15 Plus / iOS 26.5）

| Scheme | opened |
|---|---|
| `weixin://` | true |
| `snssdk1128://` | true |
| `xhsdiscover://` | true |
| `xhsdiscover://search/result?keyword=` 等 7 种搜索写法 | false（App 拒绝，已被小红书收紧） |
| `alipays://` `taobao://` `bilibili://` `zhihu://` | false |

false 不等于方案不可行，只表示该 App 在这台机器上没装、或 scheme 与版本不匹配。遇到 false 先确认安装状态。

## 不要做的事

- 不要声称「我在小红书里点开了搜索框」——做不到。
- 不要在用户没同意时把「打开 App」降级成「打开网页」。
- 不要把网页搜索结果当作 App 内结果汇报。
