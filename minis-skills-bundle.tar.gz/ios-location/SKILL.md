---
name: ios-location
description: iPhone 虚拟定位助手：选点、生成 Shadowrocket/Surge/Loon/Quantumult X/Stash 的定位改写模块、起本地地图选点服务、说明各方案（MITM / USB / 越狱）优劣。用户提到虚拟定位、改定位、模拟位置、定位漂移、钉钉/微信打卡定位、小火箭改定位、GPX、位置伪造、pymobiledevice3 时使用。
---

# iOS 虚拟定位（Minis 版）

## 先说清楚能力边界

**Minis 自己不能伪造本机定位。** 实测过：iSH 里连本机 `lockdownd:62078` 被沙箱拒绝（EPERM），
`usbmuxd:27015` 无监听，`/var/run/usbmuxd` 与 `/Developer` 都不存在，`pymobiledevice3` 装上也拿不到 USB 通道。
Minis 没有 Network Extension，进不了系统定位链路；`apple-location` 只能读不能写。

所以本技能干的是**上游工作**：选点、算坐标、生成可直接导入的模块。真正改坐标的是代理 App 里的 MITM 脚本。

## 原理

iOS 靠周围 Wi-Fi/基站向 Apple 的 `gs-loc.apple.com/clls/wloc` 发 BSSID/CellID 列表，
Apple 回坐标清单，系统再三角定位。把这条 HTTPS 回包解密后改写经纬度，系统就"以为"自己在别处。
只影响网络定位，不动 GPS 硬件 —— 但系统层面看起来就是真实定位，风控很难分辨。

## 命令

```
loc set 上海外滩              # 地名 → 坐标（走 apple-location，免 key）
loc set 31.2382,121.4973     # 直接给坐标，可加 --alt 海拔
loc build [--host fastly]    # 生成 5 平台模块到 out/
loc serve [--port 8899]      # 本地选点页 + /loc.json（需 Minis 在前台）
loc show
loc doctor
```

生成物在 `/var/minis/workspace/ios-location/out/`：
`shadowrocket.sgmodule` / `surge.sgmodule` / `loon.lnplugin` / `quantumult-x.js` / `stash.stoverride`

`--host` 控制脚本源：`fastly`（默认，国内可达）/ `jsdelivr` / `raw`，也可直接传 URL。

## 用户要自己做的四步（Shadowrocket）

1. 配置 → 模块 → `+` → 来自文件（选生成的 .sgmodule）或来自 URL
2. 配置 → 当前配置 → ⓘ → HTTPS 解密 打开；域名列表要有
   `gs-loc.apple.com, gs-loc-cn.apple.com, gsp-ssl.ls.apple.com, bluedot.is.autonavi.com,
   bluedot.is.autonavi.com.gds.alibabadns.com`
3. 生成 CA → 安装证书 → **设置 → 通用 → 关于本机 → 证书信任设置 → 打开完全信任**（90% 的人漏这步）
4. 开代理 → 关开一次定位服务 → 地图验证

## 坑

- **iOS 26+ 有 locationd 内存缓存**：改了不生效就**重启手机**，飞行模式/关定位清不掉。
- **iOS 27 正式版**：这套 MITM 已被苹果封堵，无效。iOS 26.5 可用但偶发不生效。
- 海拔要跟纬度匹配（上海几米、拉萨 3650 米），只改经纬度容易露馅。
- 别用 loc567 那类"纯网页"第三方服务：本质是让你连**它家的 VPN** 做全流量 MITM，仓库代码还是个 libimobiledevice 拷贝。

## 其他路线（用户问起时对比）

- 电脑 + USB：`pymobiledevice3`（`developer dvt simulate-location set`）、GeoPort、LocWarp、iFakeLocation。
  最稳，系统级模拟，配对后可走 WiFi 无线。缺点：得有电脑。
- 自建 App：`OpenHRTT/wloc`（Swift，Packet Tunnel 本地代理，需 Xcode + 付费开发者账号自签）。
- 越狱 / TrollStore：iOS 26 基本没戏。
