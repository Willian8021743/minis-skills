"""weibo-hub scripts package."""
