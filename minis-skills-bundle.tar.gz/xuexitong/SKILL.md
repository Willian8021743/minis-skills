---
name: xuexitong
description: >-
  学习通（超星/尔雅）全能助手：查课表、作业与截止日期、成绩、章节进度、通知、考试安排，下载课件资料，
  辅助作答作业并暂存草稿，把截止日期做成 iOS 提醒。用户提到学习通、超星、尔雅、网课、刷课、签到、
  任务点、课件、资料下载、作业、交作业、章节测验、考试成绩、班级通知时一律使用本技能，
  即使用户没说"学习通"三个字（例如"我还有啥没交""这周几节课""帮我把实验报告写了"）。
license: MIT
compatibility: 需要 iSH shell（python3 + requests + pycryptodome 已装）。写操作需要 browser_use 工具。
metadata:
  version: "1.0.0"
  homepage: https://github.com/Han-maker-wp/xuexitong-skill
---

# 学习通助手（Minis 版）

三层结构，**先读后写**，能用命令行解决的绝不开浏览器。

| 层 | 工具 | 干什么 | 速度 |
|---|---|---|---|
| L1 数据层 | `xxt`（本地 CLI，直连学习通 HTTP 接口） | 课表/作业/截止/成绩/进度/通知/考试/资料/下载 | 0.3~3 秒 |
| L2 操作层 | `browser_use`（真实浏览器，复用用户登录态） | 作答、暂存、点按钮、抓 iframe 里的页面 | 分钟级 |
| L3 本地层 | `apple-reminders` / `minis-scheduled` / `.ics` | 截止提醒、课前提醒、日历订阅 | 即时 |

## L1：xxt 命令（默认先跑这个）

```bash
xxt status                         # 登录态 + 姓名学校
xxt brief --human                  # 一句话总览：今天课 + 待交 + 未读通知
xxt courses                        # 课程列表
xxt schedule --human               # 本周课表
xxt schedule --week 5 --human      # 第 5 周
xxt schedule --ics ~/课表.ics      # 全学期导出日历
xxt homework                       # 全部课程作业（未交高亮）
xxt homework 数据结构              # 单课作业（课程名可模糊匹配）
xxt deadlines --days 7 --human     # 未来 7 天截止看板
xxt progress --human               # 各课任务点完成度
xxt chapters 数据结构 --human      # 章节树 + 任务点
xxt exams --human                  # 考试安排
xxt notices --unread --human       # 未读通知
xxt remind --days 14 --dry-run     # 把待交作业写成 iOS 提醒（先预览，去掉 --dry-run 才真建）
xxt materials 数据结构 --keyword 实验   # 递归搜资料
xxt download 数据结构 123456 --dir /var/minis/workspace/xuexitong/dl
xxt page "<url>"                   # 任意学习通页面转纯文本
```

- 默认输出 JSON（你自己解析），加 `--human` 给人看的文本。
- 命令失败会返回 `ok:false` + `hint`，**先看 hint 再决定要不要开浏览器**。
- 需要登录时：`xxt status` 返回 `ok:false` → 走下面的「首次登录」。

## 一句话路由表

| 用户说 | 你做什么 |
|---|---|
| 我还有啥没交 / 今天要交什么 / 作业 | `xxt deadlines --days 14 --human`，按「已过期 → 今天 → 本周 → 以后」分组回答 |
| 这周几节课 / 明天有课吗 / 课表 | `xxt brief --human`（今天）或 `xxt schedule --week N --human`。注意：本账号学习通课表为空，先跑 `xxt schedule --week 1` 判断是不是学校没导课 |
| 帮我盯着截止 / 提醒我 | `xxt remind --days 14 --dry-run` 预览 → 确认后去掉 `--dry-run` 真建（自动去重，提前 24h）。需要更早的提醒用 `--lead 48` |
| 下载课件 / 资料 / PPT | `xxt materials <课程>` 找 data_id → `xxt download`。下载失败再走 references/download.md |
| 查成绩 / 进度 / 通知 / 考试 | `xxt progress` / `xxt notices --unread` / `xxt exams` |
| 做作业 / 写作业 / 章节测验 | **L2**：读 `references/homework.md` 全文，按流程走。默认只暂存 |
| 交上去 / 帮我提交 | 先复述「即将提交 XX 课程 XX 作业，共 N 题」并要一句确认，再点提交 |
| 签到 / 刷课 / 任务点 | 读 `references/signin.md` / `references/tasks.md`，它们是灰色功能，先读风险框 |
| 登录过期 | 见下方「首次登录」 |

## 登录状态

**本机已配置**：`/var/minis/workspace/xuexitong/state/config.json`（手机号+密码）+ `session_cookies.json`（会话，已实测有效）。
一般直接跑命令即可；`xxt status` 返回 `ok:false` 时才需要重新登录：

1. **账号密码**：`xxt login`（读 config.json，无参数）
2. **环境变量**：设 `CHAOXING_PHONE` / `CHAOXING_PASSWORD` 后 `xxt login`
3. **浏览器扫码**：浏览器登录 → `get_cookies` → `xxt import-cookies <file>`

## L2：浏览器操作

先读 `references/minis-browser.md`（Minis 版动作映射）。三条硬规则：

1. 学习通主内容在**跨域 iframe** 里。`execute_js` 拿不到子 iframe 的内容——用 `browser_use` 的 `click`/`get_text` 配 CSS 选择器，或直接 `navigate` 到 iframe 的 `src`（部分接口会报"无权限"，报错就回退）。
2. 页面改版导致选择器失效时，**先截图看**，别猜。
3. 提交类按钮一律 `find_elements` 确认文案后再点。

## 红线（与用户指令冲突时，先提醒一次再执行）

1. **提交与否，以用户当场指令为准**。用户说"你交/帮我交了"→ 直接点提交，不再追问；用户说"我自己交/我最后提交"→ 填完就停手，一个按钮都不碰。不要替用户判断该不该交，也不要反复确认。
   - 事实（不是规矩）：学习通的「暂时保存」实际会交卷并判分，做不到只存草稿。用户要求"保存草稿"时如实说明这一点，由用户决定。
2. **不进入有监考/限时/防作弊的正式考试**，只做时间与状态查询。
3. **不伪造签到证据**（照片/坐标/enc/签到码）。签到默认只检测提醒；用户本人提供证据并当场指示时才代提交，每次单独确认。
4. **视频挂机默认关闭**，只在用户当场明确要求时执行，且只在真实浏览器里正常倍速播放。
5. 账号密码不写进任何文件、不回显、不写日志。

## 出错时

1. 先看 `xxt` 返回的 `hint`。
2. 再查 `references/pitfalls.md`（29 条真机踩坑表）。
3. 还不行就开浏览器截图，现场用 `document.querySelectorAll` 探测真实结构，并在汇报里注明哪条文档需要更新。

## 汇报格式

- 做了什么（查询/下载/暂存，数量 + 文件路径）
- 状态：哪些草稿已暂存待审、哪些没动
- 异常与处理
- 下一步建议（最近的两个截止、该提醒的时间）

## 签到（xxt sign）

```bash
xxt sign list                  # 进行中的签到（只列 activeType=2）
xxt sign watch --interval 30 --auto   # 轮询+弹通知+自动签普通/位置签到
xxt sign do <id>               # 手动签
xxt sign qr <图片>             # 二维码：apple-vision 识别 → enc → 提交
xxt sign code <数字>           # 数字码/手势码
```

- `--auto` **只处理 activeType=2（签到）**，问卷/讨论/抢答/章节测验一律不碰，代码层过滤。
- 位置签到：先不带坐标提交，失败后用 `apple-location` 取真实定位重试。定位权限需用户开启。
- **不做虚拟定位**：不接受外部伪造坐标。

## 课表与按课表轮询

```bash
xxt class sync                 # 重新拉取 iCloud 课表 (state/calendar.url)
xxt class list [--date D]      # 某天的课
xxt sign daemon --lead 10 --interval 25   # 只在有课时段轮询，其余时间休眠
```

- 课表来源：iCloud 公开日历（webcal），解析后存 `state/classes.ics`，每天首次运行自动刷新
- `daemon` 每天按课表算窗口（课前 10 分钟 → 下课后 5 分钟），窗口内每 25 秒扫一次签到，窗口外每 5 分钟醒一次看表，不发请求
- 只处理 `activeType=2`（签到），其他活动一律不碰
- 进程随 Minis 存活，App 被杀则停
