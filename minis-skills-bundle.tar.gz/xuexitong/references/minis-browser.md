# Minis 浏览器动作映射（browser_use）

本技能里的语义动作（goto / evalJs / 截图 / 点击）按这张表落到 Minis 的 `browser_use` 工具。

| 语义动作 | Minis 写法 |
|---|---|
| `goto(url)` | `browser_use(action="navigate", url=...)` |
| `evalJs(js)`（主文档） | `browser_use(action="execute_js", script="...")`，脚本里可 `await`、可 `return` |
| 读某块文本 | `browser_use(action="get_text", selector="...")` |
| 截图 | `browser_use(action="screenshot")` |
| 点按钮 | `browser_use(action="click", selector="...")`，选择器不稳时用 `coordinate_x/y` |
| 找可点元素 | `browser_use(action="find_elements")` |
| 等页面稳定 | `browser_use(action="wait_for_dom_stable", timeout=15)` |
| 整页正文 | `browser_use(action="get_readable")` |
| 长列表滚动 | `browser_use(action="scroll_and_collect", item_selector="...")` |

## 跨域 iframe（学习通的最大坑）

学习通的课程内容、作业列表、作答页大多在 iframe 里（`#frame_content` 等），**跨域**，所以 `execute_js` 在主页面上读不到里面的 DOM。按顺序试：

1. **`get_text` 带 iframe 内选择器**：Minis 的 `get_text` 有时能穿透，先试一次，返回空就换下一条。
2. **直接 `navigate` 到 iframe 的 src**：src 属性在主文档永远读得到
   （`execute_js: return document.querySelector('#frame_content').src`）。
   注意：`work/list`、`mooc2-ans/...` 这类**新接口会报「无权限的操作」**，此时带 referer 也没用——回退第 3 条。
3. **`click` 用坐标**：先用 `find_elements` 或 `execute_js` 在**主文档**里估算元素位置，再 `coordinate_x/y` 点。iframe 内元素点得到，因为点击是原生事件。

已知可用的导航链（2026-09 真机校准）：

```
i.chaoxing.com
  → execute_js 读 #frame_content 的 src，取 s= 参数
  → navigate https://i.chaoxing.com/base?...
  → 或 navigate 到 visit/interaction?s=<s>（缺 referer 直接 goto 课程会弹回首页）
```

## 其它硬规则

1. **frame 上下文里禁用 evaluate**：部分运行时会静默返回空对象，误判成"页面没内容"。iframe 内只用点击/截图/文本提取。
2. **`ERR_ABORTED(-3)` 假死**：导航全挂（连外部站点都失败）时开新标签页（`new_tab`）即恢复，登录态不丢。
3. **长字符串上限约 1MB**：`scripts/*.js` 整段塞进 `execute_js` 没问题，但别把整页 HTML 回传。
4. **截图前确认页面已加载完**：`wait_for_dom_stable` → `screenshot`，别连拍。
5. `scripts/*.js` 是"整段粘进 evaluate 的回调函数"：读文件内容 → 作为 `script` 传给 `execute_js` → 返回 JSON。

## 实测记录：作业作答页（2026-10-20）

`mooc1.chaoxing.com/mooc-ans/mooc2/work/task?...` 会 302 到 `work/dowork?...`，**页面本身在主文档，没有 iframe**，可直接 `execute_js`：

- 题干：`.questionLi[data=<qid>] .mark_name`（含题号+题型+题干）
- 选项：同题下 `.answerBg`，字母在 `span.num_option[data="A"]`
- 答案落在隐藏域 `#answer<qid>`
- 选答**不要手动改 input**，调页面自己的 `addChoice(optionDiv)`；注意它是**开关式**——同一选项连点两次会取消，重复执行前先读 `#answer<qid>` 判断
- **「暂时保存」= 交卷**（2026-10-20 实测：点 `saveWork()` 后作业直接变「已完成」并判分，不可撤回）。它做不到只存草稿——用户要"保存"时先说明，再按用户指令做。
  该按钮内部 `saveAnswer()` 带 `pyFlag=1&saveStatus=1` 走的是提交接口，名字骗人。`提交` → `submitValidate()`。
- 用户说"我交"：填完停手，截图留证。用户说"你交"：填完直接点 `submitValidate()` 提交。
- 核验方式：`navigate` 同一 URL 重新加载，看 `#answer<qid>` 是否还在（在 = 暂存成功）
