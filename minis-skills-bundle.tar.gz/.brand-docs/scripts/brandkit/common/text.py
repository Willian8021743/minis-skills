# SPDX-License-Identifier: MIT
"""Text utilities: rich-run helpers, markdown-literal detection, slugs, and the
multilingual name-token lexicon used by role inference.

This module pulls in NO heavy OOXML stack (no lxml / python-docx) so every layer
of the engine can import it cheaply. It does lean on the two equally light pure-
Python siblings ``brandkit.common.color`` and ``brandkit.profile.schema`` for the
run color-TOKEN validator (the hex-rejection rule), both of which are themselves
lxml/python-docx-free at import.

Four concerns:

1. **Rich runs** - the inline text model shared by the IntermediateDocument and
   the resolver. A *run* is a ``{"t": str, "b"?: bool, "i"?: bool, "u"?: bool,
   "code"?: bool, "link"?: str}`` dict. Helpers normalize loose input (a bare
   string, a list of runs, the ``text:`` sugar) into a canonical run list and
   flatten runs back to plain text.
2. **Markdown-literal detection** - the L0 ``markdown_literal`` checker must
   catch literal ``**bold**``, ``*i*``, `` `code` ``, ``## heading``, and table
   ``|`` pipes that leaked into rendered text. :data:`MARKDOWN_LITERAL_RE` and
   :func:`find_markdown_literals` are the shared detector.
3. **Slug / safe filename** - deterministic, filesystem-safe identifiers for
   brand-kit directory names and asset filenames.
4. **Name-token lexicon (a WEAK PRIOR, never a gate)** - multilingual word lists
   the role-inference scorer consults as its *weakest* (0.20) signal and only as
   a LAST RESORT. The PRIMARY signals are structural, language-invariant OOXML
   facts (builtin style ids, field codes, SDT flags, placeholder TYPES,
   named-range geometry); the lexicon merely ADDS weak positive evidence when no
   structural signal is available and never gates output. See
   :data:`NAME_TOKEN_LEXICON` for the full anti-overfitting contract. Tokens
   cover EN/IT/FR/DE/ES.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Iterable, Optional, Union

from brandkit.common import color as colorutil
from brandkit.profile import schema

# A canonical inline run. Only "t" is required.
Run = dict
RunInput = Union[str, dict, Iterable[dict], None]


# ---------------------------------------------------------------------------
# Rich runs
# ---------------------------------------------------------------------------
# The boolean toggle keys a run may carry, plus the string "link" key.
RUN_TOGGLE_KEYS: tuple[str, ...] = ("b", "i", "u", "strike", "code", "sup", "sub")
RUN_STRING_KEYS: tuple[str, ...] = ("link",)
# A run may ALSO carry a ``color`` palette TOKEN (model-driven color, the APPLY
# half): a template-derived id (a theme slot like ``accent1``, or a comprehension-
# named palette key) the resolver maps to ``theme.palette[token]['ref']``. It is a
# TOKEN, never a literal color: :func:`is_valid_color_token` rejects any hex-shaped
# string STRUCTURALLY, so a literal RRGGBB / ``#rgb`` can never enter the IDoc.
RUN_PALETTE_KEYS: tuple[str, ...] = ("color",)


def is_valid_color_token(value: object) -> bool:
    """Return True if ``value`` is a syntactically valid run COLOR palette token.

    A color token names a key into ``theme.palette`` (a theme slot like ``accent1``
    or a comprehension-named id), so it must have the role-id/region-token shape
    (dotted lowercase). It is NEVER a literal color: any hex-shaped string is
    rejected structurally - anything :func:`colorutil.normalize_hex` would accept
    (``abcdef`` / ``fff`` / any case) and anything containing ``#``. This is what
    keeps a literal hex from ever reaching the writer through the IDoc; a rejected
    value is dropped like a falsy toggle (the run is left to inherit its color)."""
    if not isinstance(value, str) or not value:
        return False
    if "#" in value:
        return False
    if not (schema.is_valid_region_token(value) or schema.is_valid_role_id(value)):
        return False
    # Reject anything that PARSES as a hex color (e.g. the lowercase ``abcdef`` that
    # the role-id regex would otherwise accept), so no literal color slips through.
    if colorutil.is_hex(value):
        return False
    return True


def normalize_runs(value: RunInput, *, text: Optional[str] = None) -> list[Run]:
    """Coerce loose inline input into a canonical list of run dicts.

    Accepts, in priority order:
      - ``value`` already a list/tuple of run dicts -> validated & copied.
      - ``value`` a single run dict -> wrapped in a one-element list.
      - ``value`` a plain ``str`` -> ``[{"t": value}]``.
      - ``value`` falsy and ``text`` given (the ``text:`` block sugar) ->
        ``[{"t": text}]``.
      - everything falsy -> ``[]``.

    Each produced run keeps only recognised keys (``t`` + the toggle/link keys +
    a valid ``color`` palette token), drops falsy toggles, and guarantees ``t`` is
    a ``str``. A ``color`` that is not a valid palette TOKEN (hex-shaped, ``#``-
    bearing, or not a dotted-lowercase id) is DROPPED structurally - it never enters
    the IDoc - so a literal color can never reach the writer through a run.
    """
    if value is None or value == "":
        if text:
            return [{"t": str(text)}]
        return []
    if isinstance(value, str):
        return [{"t": value}] if value else []
    if isinstance(value, dict):
        runs_in: Iterable[dict] = [value]
    else:
        runs_in = list(value)  # type: ignore[arg-type]
    out: list[Run] = []
    for r in runs_in:
        if not isinstance(r, dict):
            # Tolerate a stray plain string inside a list.
            if isinstance(r, str) and r:
                out.append({"t": r})
            continue
        t = str(r.get("t", ""))
        run: Run = {"t": t}
        for k in RUN_TOGGLE_KEYS:
            if r.get(k):
                run[k] = True
        for k in RUN_STRING_KEYS:
            if r.get(k):
                run[k] = str(r[k])
        # A color palette TOKEN is preserved ONLY when it passes the structural
        # token guard (dotted-lowercase id, never hex-shaped / ``#``-bearing); any
        # other value is dropped like a falsy toggle so no literal color can enter
        # the IDoc through a run.
        for k in RUN_PALETTE_KEYS:
            if is_valid_color_token(r.get(k)):
                run[k] = str(r[k])
        out.append(run)
    return out


def runs_to_text(runs: Iterable[Run]) -> str:
    """Flatten a run list to its concatenated plain text."""
    return "".join(str(r.get("t", "")) for r in runs)


def plain_run(text: str) -> list[Run]:
    """Return a single-run list for plain ``text`` (``[]`` if empty)."""
    return [{"t": text}] if text else []


# ---------------------------------------------------------------------------
# Markdown-literal detection
# ---------------------------------------------------------------------------
# Each alternative names a leaked markdown construct. The detector is
# deliberately conservative: it targets the markers most likely to survive into
# a *rendered* document (where they are always wrong), not every theoretical
# markdown token.
_MD_PATTERNS: tuple[tuple[str, str], ...] = (
    ("bold", r"\*\*[^\s*][^*]*?\*\*"),  # **bold**
    ("bold_underscore", r"__[^\s_][^_]*?__"),  # __bold__
    ("italic", r"(?<![\*\w])\*[^\s*][^*]*?\*(?![\*\w])"),  # *italic*
    ("code", r"`[^`\n]+?`"),  # `code`
    ("heading", r"^\s{0,3}#{1,6}\s+\S"),  # ## heading (line start)
    ("bullet", r"^\s{0,3}[-*+]\s+\S"),  # - bullet (line start)
    ("link", r"\[[^\]]+\]\([^)]+\)"),  # [text](url)
    ("table_pipe", r"^\s*\|.+\|\s*$"),  # | a | b | table row
)

# MULTILINE so the line-anchored alternatives (heading/bullet/table_pipe) match
# at every embedded line start, not just the string start. The inline ``(?m)``
# flag is disallowed mid-pattern on Python 3.11+, so the flag is set here.
MARKDOWN_LITERAL_RE = re.compile(
    "|".join(f"(?P<{name}>{pat})" for name, pat in _MD_PATTERNS),
    re.MULTILINE,
)


def find_markdown_literals(text: str) -> list[dict]:
    """Return every markdown-literal match in ``text``.

    Each result is ``{"kind": <pattern-name>, "match": <substring>,
    "start": int, "end": int}``. An empty list means the text is clean. This is
    the shared detector behind the L0 ``markdown_literal`` checker; keeping it
    here makes the same rule format-agnostic across docx/pptx/xlsx.
    """
    out: list[dict] = []
    for m in MARKDOWN_LITERAL_RE.finditer(text or ""):
        out.append(
            {
                "kind": m.lastgroup,
                "match": m.group(),
                "start": m.start(),
                "end": m.end(),
            }
        )
    return out


# ---------------------------------------------------------------------------
# Slug
# ---------------------------------------------------------------------------
_SLUG_STRIP_RE = re.compile(r"[^a-z0-9]+")
_SLUG_TRIM_RE = re.compile(r"^-+|-+$")


def slugify(value: str, *, max_len: int = 64, default: str = "untitled") -> str:
    """Return a lowercase, hyphenated, ASCII slug suitable for a directory name.

    Unicode is transliterated to its ASCII approximation (NFKD + drop combining
    marks); runs of non-alphanumerics collapse to a single hyphen; leading and
    trailing hyphens are trimmed. An empty result falls back to ``default``.
    """
    norm = unicodedata.normalize("NFKD", value or "")
    ascii_only = norm.encode("ascii", "ignore").decode("ascii").lower()
    slug = _SLUG_STRIP_RE.sub("-", ascii_only)
    slug = _SLUG_TRIM_RE.sub("", slug)
    if max_len and len(slug) > max_len:
        slug = _SLUG_TRIM_RE.sub("", slug[:max_len])
    return slug or default


# ---------------------------------------------------------------------------
# Multilingual name-token lexicon for role inference (WEAK PRIOR ONLY).
# ---------------------------------------------------------------------------
# IMPORTANT (plan §5 / M-i-8 lexicon demotion): this lexicon is the engine's
# *weakest* signal and a LAST-RESORT TIEBREAKER, retained ONLY for the
# comprehension-absent deterministic path. It is deliberately NOT deleted - it is
# the only thing left to nudge an ambiguous custom-named style when no structural
# evidence exists - but it has been firmly DEMOTED below every structural signal:
#
#   PRIMARY (language-invariant, structural OOXML facts; these decide the role):
#     - docx: builtin style ids (``Heading N`` / ``Title`` / ``Caption`` /
#       ``Quote`` / ``Normal``), field codes (``w:instrText`` ``TOC`` /
#       ``TOC \c`` / ``TOC \f``), SDT flags (alias / dataBinding /
#       docPartGallery / showingPlcHdr).
#     - pptx: placeholder *types* (TITLE / SUBTITLE / BODY ...) and named layouts.
#     - xlsx: named-range geometry (single vs multi cell, merged header, freeze,
#       tables) and number formats.
#   WEAK PRIOR (this lexicon): lowercased substring containment in a style's
#     *display name*. It only ever ADDS weak positive evidence; it NEVER strips,
#     NEVER overrides a structural signal, and NEVER matches on rendered body
#     text. A role recognised *only* via this lexicon is stamped best_effort /
#     low-confidence (<= the structural floor) so it can never gate output: the
#     deterministic ``resolver_targets_exist`` / ``comprehension_targets_exist``
#     guards reject any load-bearing ref that is not a verbatim structural id.
#
# Because the signal is language-invariant at the structural layer, removing or
# editing tokens here can only ever weaken a heuristic tiebreaker - it can never
# change which output is brand-valid. That is the whole point of the demotion.
#
# Maps a semantic *role family* -> set of lowercase substrings that, when found
# in a style's display name, weakly suggest that role. EN / IT / FR / DE / ES.
# The scorer matches by lowercased substring containment, so multi-word phrases
# ("elenco puntato") and single tokens ("puce") both work.
NAME_TOKEN_LEXICON: dict[str, frozenset[str]] = {
    "heading": frozenset(
        {
            "heading",
            "title",
            "titolo",
            "titre",
            "uberschrift",
            "überschrift",
            "titulo",
            "título",
            "head",
        }
    ),
    "callout": frozenset(
        {
            "callout",
            "box",
            "riquadro",
            "encadre",
            "encadré",
            "kasten",
            "caja",
            "cuadro",
            "note",
            "nota",
            "highlight",
            "evidenza",
        }
    ),
    "list.bullet": frozenset(
        {
            "bullet",
            "elenco puntato",
            "elenchi puntati",
            "puce",
            "puces",
            "aufzahlung",
            "aufzählung",
            "vineta",
            "viñeta",
            "list",
            "elenco",
            "liste",
            "lista",
        }
    ),
    "list.number": frozenset(
        {
            "number",
            "numbered",
            "numerato",
            "numerique",
            "numérique",
            "nummeriert",
            "numerada",
            "ordered",
            "ordinato",
            "ordnung",
        }
    ),
    "table": frozenset(
        {
            "table",
            "tabella",
            "tableau",
            "tabelle",
            "tabla",
            "grid",
            "griglia",
        }
    ),
    "caption": frozenset(
        {
            "caption",
            "didascalia",
            "legende",
            "légende",
            "beschriftung",
            "leyenda",
            "figure",
            "figura",
        }
    ),
    "quote": frozenset(
        {
            "quote",
            "citazione",
            "citation",
            "zitat",
            "cita",
            "blockquote",
        }
    ),
    "cover": frozenset(
        {
            "cover",
            "copertina",
            "couverture",
            "deckblatt",
            "portada",
            "title page",
            "frontespizio",
        }
    ),
    "subtitle": frozenset(
        {
            "subtitle",
            "sottotitolo",
            "sous-titre",
            "untertitel",
            "subtitulo",
            "subtítulo",
        }
    ),
    "toc": frozenset(
        {
            "toc",
            "contents",
            "sommario",
            "indice",
            "table of contents",
            "inhaltsverzeichnis",
            "tabla de contenido",
        }
    ),
    "kpi": frozenset(
        {
            "kpi",
            "metric",
            "metrica",
            "metrik",
            "stat",
            "indicator",
            "indicatore",
            "indicador",
        }
    ),
}

# Generic company-name noise tokens are NOT hardcoded here (the noise-token
# stripper is profile-gated and learned from the template per §5.1.2). This
# lexicon only ever *adds* weak positive evidence; it never strips.
#
# The lexicon is consumed directly by the role-inference scorer (docx
# ``roles.py`` reads ``NAME_TOKEN_LEXICON`` for substring containment); there is
# no separate scoring helper here. It remains the engine's WEAKEST signal and a
# last-resort tiebreaker, never a gate.
